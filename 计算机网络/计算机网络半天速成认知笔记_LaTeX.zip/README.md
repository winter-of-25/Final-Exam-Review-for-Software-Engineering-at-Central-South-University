# 使用说明

1. 打开 Overleaf，新建项目。
2. 上传本 ZIP 文件并解压，或上传其中的 `main.tex` 与 `latexmkrc`。
3. 在 Overleaf 菜单中将 Compiler 设置为 **XeLaTeX**。
4. 编译 `main.tex`。

本文档基于你提供的学校习题与总复习题整理，用于考前快速建立计算机网络基础认知。
